﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SingletonSparesApp
{
    public sealed class SingletonClass
    {
        public string holder { get; set; }
        private SingletonClass()
        {
        }
        private static SingletonClass instance = null;
        public static SingletonClass Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new SingletonClass();
                }
                return instance;
            }
        }

        public string AddPrompt()
        {
            holder = "Added new item";
            StreamWriter add = new StreamWriter("SparesLog.txt", true);
            add.WriteLine("" + holder);
            add.Close();
            return holder;
        }

        public string DeletePrompt()
        {
            StreamWriter delete = new StreamWriter("SparesLog.txt", true);
            delete.WriteLine("Deleted an existing item");
            delete.Close();
            return holder;
        }
    }
}
