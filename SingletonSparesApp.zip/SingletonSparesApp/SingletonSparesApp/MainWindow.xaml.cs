﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace SingletonSparesApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();


        }
        private void ItemsAdd()
        {
            
            this.lsvItems.Items.Add(new ListViewItems { Col1 = txbNewItem.Text, Col2 = txbNewPrice.Text, Col3 = txbNewQuant.Text });
            
        }


        private void lsvItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            ItemsAdd();
            SingletonClass.Instance.AddPrompt();
        }

        private void txbNewQuant_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            lsvItems.Items.RemoveAt(lsvItems.Items.IndexOf(lsvItems.SelectedItem));
            SingletonClass.Instance.DeletePrompt();
        }
    }
}
